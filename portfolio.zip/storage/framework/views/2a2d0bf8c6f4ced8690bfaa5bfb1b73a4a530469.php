<?php $__env->startSection('content'); ?>
    <div class="custom-background">
        <a class="btn btn-light border border-secondary" href="/" role="button"><?php echo e(__('messages.go_back')); ?></a>
    </div>
    <hr>

    <div class="jumbotron text-center">
        <h1><?php echo e(__('messages.contact')); ?></h1>
        <br><br>
        <div class="row">
            <div class="col-md-6 order-sm-1">
                <ul class="text-left">
                    <li><?php echo e(__('messages.phone')); ?>: +372 55 83 273</li>
                    <li><?php echo e(__('messages.email')); ?>: rasmuskilk@gmail.com</li>
                    <li>LinkedIn: <a target="_blank" href="//www.linkedin.com/in/rasmus-kilk">linkedin.com/in/rasmus-kilk</a>
                    </li>
                </ul>
                <br>
            </div>
            <div class="col-md-6 order-sm-12">
                <?php echo $__env->make('gallery.include.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <h4 class="mb-2"><?php echo e(__('messages.send_me_message')); ?></h4>
                <hr>
                <?php echo Form::open(['action' => 'ContactFormController@store', 'method' => 'POST']); ?>

                <div class="form-group text-left">
                    <?php echo e(Form::label('name', __('messages.name') . ':')); ?>

                    <?php echo e(Form::text('name', '', ['class' => "form-control", 'placeholder' => __('messages.enter_name')])); ?>

                </div>
                <div class="form-group text-left">
                    <?php echo e(Form::label('email', __('messages.email') . ':')); ?>

                    <?php echo e(Form::email('email', '', ['class' => 'form-control', 'placeholder' => __('messages.enter_email')])); ?>

                </div>
                <div class="form-group text-left">
                    <?php echo e(Form::label('message', __('messages.message') . ':')); ?>

                    <?php echo e(Form::textarea('message', '', ['class' => 'form-control', 'rows' => '3', 'placeholder' => __('messages.enter_message')])); ?>

                </div>
                <?php echo e(Form::submit(__('messages.send_message'), ['class' => 'btn btn-primary btn-lg'])); ?>

                <?php echo Form::close(); ?>

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/contact/create.blade.php ENDPATH**/ ?>