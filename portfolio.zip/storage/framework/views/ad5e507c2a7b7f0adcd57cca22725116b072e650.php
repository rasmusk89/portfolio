<?php $__env->startSection('content'); ?>
    <div class="jumbotron text-center">
        <h1><?php echo e($title); ?></h1>
        <a href="albums/create" class="text-decoration-none"><div class="btn btn-dark">Create album</div></a>
        <a href="albums/albums" class="text-decoration-none"><div class="btn btn-dark">View albums</div></a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/gallery/index.blade.php ENDPATH**/ ?>
