<?php $__env->startSection('content'); ?>
    <div class="form-group">
        <h1><?php echo e($title); ?></h1>
        <form>
            <div class="form-group">
                <label for="albumTitle">Album title</label>
                <input type="text" class="form-control" id="albumTitle" placeholder="Album title">
            </div>
            <div class="form-group">
                <label for="albumDescription">Album description</label>
                <textarea class="form-control" id="albumDescription" rows="3" placeholder="Album description"></textarea>
            </div>
            <div class="form-group">
                <label for="chooseFile">Choose a cover image</label>
                <input type="file" class="form-control-file" id="chooseFile">
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/gallery/create/create.blade.php ENDPATH**/ ?>
