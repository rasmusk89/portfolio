<?php $__env->startSection('content'); ?>
    <div class="custom-background">
        <a class="btn btn-light border border-secondary" href="/projects" role="button"><?php echo e(__('messages.go_back')); ?></a>
    </div>
    <hr>
    <div class="custom-background">
        <?php echo $__env->make('gallery.include.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if(!Auth::check()): ?>
            <small><em><?php echo e(__('projects.guest_login')); ?></em></small>
        <?php endif; ?>
    </div>
    <hr>
    <div class="jumbotron text-center">
        <h1><?php echo e(__('messages.photo_gallery')); ?></h1>
        <p><?php echo e(__('projects.photo_gallery_description')); ?></p>
        <?php if(Auth::check()): ?>
            <a href="gallery/create" class="text-decoration-none">
                <div class="btn btn-dark m-2"><?php echo e(__('messages.create_album')); ?></div>
            </a>
        <?php endif; ?>
        <a href="gallery/albums" class="text-decoration-none">
            <div class="btn btn-dark m-2"><?php echo e(__('messages.view_albums')); ?></div>
        </a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/gallery/index.blade.php ENDPATH**/ ?>