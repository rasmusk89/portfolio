<?php $__env->startSection('content'); ?>
    <div class="custom-background">
        <a class="btn btn-light border border-secondary" href="/gallery/albums/<?php echo e($photo->album_id); ?>"
           role="button"><?php echo e(__('messages.go_back')); ?></a>
    </div>
    <hr>
    <div class="custom-background">
        <?php echo $__env->make('gallery.include.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <hr>
    <div class="custom-background text-center">
        <h3><?php echo e($photo->title); ?></h3>
        <p><?php echo e($photo->description); ?></p>

        <a href="<?php echo e(URL::asset("gallery/albums/{$photo->album_id}/")); ?>">
            <img width="100%" src="<?php echo e(URL::asset("storage/photos/{$photo->album_id}/{$photo->photo}")); ?>"
                 alt="<?php echo e($photo->title); ?>">
        </a>
        <br><br>

        <?php if(! Auth::guest()): ?>
            <?php if($photo->user_id == Auth::user()->id): ?>
                <?php echo Form::open(['action' => ['PhotosController@destroy', $photo->id], ',method' => 'POST']); ?>


                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                <?php echo e(Form::submit(__('messages.delete_photo'), ['class' => 'btn btn-danger'])); ?>


                <?php echo Form::close(); ?>

            <?php endif; ?>
        <?php endif; ?>
        <small><?php echo e(__('messages.size')); ?>: <?php echo e($photo->size); ?></small>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/gallery/photos/show.blade.php ENDPATH**/ ?>