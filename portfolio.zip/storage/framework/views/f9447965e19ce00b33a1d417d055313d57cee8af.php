<?php
use Illuminate\Support\Facades\App;
$language = APP::getLocale();
echo $language;
?>



<?php /**PATH C:\xampp\htdocs\portfolio\resources\views/include/get_language.blade.php ENDPATH**/ ?>