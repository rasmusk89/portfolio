<?php $__env->startSection('content'); ?>
    <div class="custom-background">
        <a class="btn btn-light border border-secondary" href="/projects" role="button"><?php echo e(__('messages.go_back')); ?></a>
    </div>
    <hr>
    <div class="jumbotron text-center">
        <h1><?php echo e(__('projects.contacts_school_project')); ?></h1>
        <p><?php echo e(__('projects.contacts_school_project_description')); ?></p>
        <a href="https://github.com/rasmusk89/Contact-book" target="_blank" class="text-decoration-none">
            <div class="btn btn-dark"><?php echo e(__('messages.view')); ?> GitHub</div>
        </a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/contacts_school/index.blade.php ENDPATH**/ ?>