<?php $__env->startSection('content'); ?>
    <div class="custom-background">
        <a class="btn btn-light border border-secondary" href="/projects" role="button"><?php echo e(__('messages.go_back')); ?></a>
    </div>
    <hr>
    <div class="jumbotron text-center">
        <h1><?php echo e($title); ?></h1>
        <p><?php echo e(__('projects.gifs_description')); ?></p>
        <?php echo $__env->make('gifs.include.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="custom-background">
        <?php echo Form::open(['action' => 'GiphyController@search', 'method' => 'POST']); ?>

        <div class="row">
            <div class="col-md-6">
                <div class="m-1">
                    <?php echo e(Form::text('search', '', ['class' => "form-control", 'placeholder' => __('messages.desc_gifs')])); ?>

                </div>
                <div class="m-1">
                    <?php echo e(Form::submit(__('messages.search'), ['class' => 'btn btn-primary btn-md'])); ?>

                </div>
            </div>
            <div class="col-md-6">
                <div>
                    <p><?php echo e(__('messages.how_many')); ?>:</p>
                </div>
                <div>
                    <?php echo e(Form::select('limit', array(1 => __('messages.one'), 5 => __('messages.five'), 10 => __('messages.ten')))); ?>

                </div>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
    <div class="custom-background">
        <?php if(count($images) != 0): ?>
            <a class="btn btn-light border border-secondary" href="/gifs" role="button"><?php echo e(__('messages.go_back')); ?></a>

            <div>
                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img class="m-2 border border-light" style="max-width: 300px;max-height: 200px" src="<?php echo e($image); ?>"
                         alt="<?php echo e($image); ?>">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/gifs/index.blade.php ENDPATH**/ ?>