<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css?v=').time()); ?>">
    <link rel="dns-prefetch" href="//fonts.gstatic.com">

    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <title>Rasmus Kilk - <?php echo e(config('app.name', 'My projects page')); ?></title>
</head>
<body >
<div class="background">
<div class="d-flex flex-column min-vh-100">
    <?php echo $__env->make('include.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <footer class="mt-auto footer">
        <ul class="text-muted text-center list-unstyled">
            <li>Rasmus Kilk 2020</li>
            <li>+372 55 83 273</li>
            <li>rasmuskilk@gmail.com</li>
        </ul>
    </footer>
</div>
</div>
<script src="/js/app.js"></script>
</body>
</html>

<?php /**PATH C:\xampp\htdocs\portfolio\resources\views/layouts/app.blade.php ENDPATH**/ ?>