<ul class="list-unstyled">
    <li class="nav-item text-decoration-none">
        <a class="nav-link" href="/albums"><div class="btn btn-dark">Go back</div></a>
    </li>
</ul>
<hr>
<?php /**PATH C:\xampp\htdocs\portfolio\resources\views/gallery/include/navbar.blade.php ENDPATH**/ ?>
