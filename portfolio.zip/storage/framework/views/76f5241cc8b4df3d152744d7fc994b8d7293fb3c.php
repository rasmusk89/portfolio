<?php $__env->startSection('content'); ?>
    <a class="btn btn-dark" href="/projects" role="button"><?php echo e(__('messages.go_back')); ?></a>
    <hr>
    <div class="jumbotron text-center">
        <h1><?php echo e(__('messages.contact_book')); ?></h1>
        <p>Description of work</p>
        <a href="/contact_book/contacts" class="text-decoration-none"><div class="btn btn-dark"><?php echo e(__('messages.go_to')); ?>..</div></a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/contact_book/index.blade.php ENDPATH**/ ?>