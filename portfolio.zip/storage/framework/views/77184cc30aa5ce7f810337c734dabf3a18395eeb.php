<?php $__env->startSection('content'); ?>
    <div class="custom-background">
        <a class="btn btn-light" href="/projects" role="button"><?php echo e(__('messages.go_back')); ?></a>
    </div>
    <hr>
    <div class="jumbotron text-center">
        <h1><?php echo e(__('projects.product_api')); ?></h1>
        <p><?php echo e(__('projects.product_api_description')); ?></p>
        <a href="//rasmusk.ee/productAPI" target="_blank" class="text-decoration-none">
            <div class="btn btn-dark m-2"><?php echo e(__('messages.view')); ?>..</div>
        </a>
        <a href="https://github.com/rasmusk89/TestWork" target="_blank" class="text-decoration-none">
            <div class="btn btn-dark m-2">GitHub..</div>
        </a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/productapi/index.blade.php ENDPATH**/ ?>