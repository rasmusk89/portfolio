<?php $__env->startSection('content'); ?>
    <div class="custom-background">
        <a class="btn btn-light border border-secondary" href="/" role="button"><?php echo e(__('messages.go_back')); ?></a>
    </div>
    <hr>
    <div class="jumbotron text-center">
        <h1 class="mb-3 text-center"><?php echo e($title); ?></h1>
        <div class="row">
            <div class="col-md-6 order-lg-12 order-sm-1 align-self-center">
                <img src="storage/profile/profile.jpg" alt="profile image" height="200em" class="rounded-circle mb-3">
            </div>
            <div class="col-md-6 order-lg-1 order-sm-12 align-self-center">
                <ul class="list-unstyled">
                    <li><strong><?php echo e(__('about.name')); ?></strong>: Rasmus Kilk</li>
                    <li><strong><?php echo e(__('about.location')); ?></strong>: Tartu, Eesti</li>
                </ul>
            </div>

        </div>
        <h3><?php echo e(__('about.education')); ?></h3>
        <div class="border border-bottom border-dark"></div>
        <ul class="list-unstyled">
            <li>
                &nbsp;<strong><?php echo e(__('about.university')); ?></strong><br>
                <em><?php echo e(__('about.distant')); ?></em><br>
                &nbsp;2019 -<br>
                &nbsp;<?php echo e(__('about.field')); ?><br>
            </li>
            <hr>
            <li>
                &nbsp;<strong>Kose Gümnaasium</strong><br>
                &nbsp;2006 - 2009<br>
                &nbsp;<?php echo e(__('about.secondary')); ?><br>
            </li>
            <hr>
            <li>
                &nbsp;<strong>Roosna-Alliku Põhikool</strong><br>
                &nbsp;1997 - 2006<br>
                &nbsp;<?php echo e(__('about.basic')); ?><br>
            </li>
            <br>
            <h3><?php echo e(__('about.certificates')); ?></h3>
            <div class="border border-bottom border-dark"></div>
            <li>
                <strong><?php echo e(__('about.front_end')); ?></strong><br>
                &nbsp;IT Koolitus - 2019<br>
                &nbsp;72 <?php echo e(__('about.academical_hours')); ?><br>
                &nbsp;<em>Git, HTML, CSS, JavaScript, DOM, JSON, AJAX, unit test, SEO</em><br>
            </li>
            <hr>
            <li>
                <strong><?php echo e(__('about.it_specialist')); ?></strong><br>
                &nbsp;N.O.R.T Koolitus - 2018<br>
                &nbsp;40 <?php echo e(__('about.academical_hours')); ?><br>
                &nbsp;<em><?php echo e(__('about.hardware')); ?></em><br>
            </li>
            <br>
        </ul>
        <h3><?php echo e(__('about.skills')); ?></h3>
        <div class="border border-bottom border-dark"></div>
        <ul class="text-center list-unstyled">
            <li>PHP</li>
            <li>JAVA</li>
            <li>Python</li>
            <li>HTML5</li>
            <li>CSS</li>
            <li>MySQL</li>
            <li>Laravel</li>
            <li>REST API</li>
            <li>VUE.JS</li>
            <li>Wordpress</li>
        </ul>
        <div class="text-center">
            <a class="btn bg-light btn-lg mt-5 border border-dark" href="/contact"><?php echo e(__('messages.contact_me')); ?>..</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/pages/about.blade.php ENDPATH**/ ?>