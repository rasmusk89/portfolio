<?php $__env->startSection('content'); ?>
    <div class="custom-background">
        <a class="btn btn-light" href="/gallery" role="button"><?php echo e(__('messages.go_back')); ?></a>
    </div>
    <hr>
    <div class="custom-background">
        <?php echo $__env->make('gallery.include.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <hr>
    <div class="custom-background">
        <div class="container">
            <?php echo $__env->make('gallery.include.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="form-group ml-3">
            <h1><?php echo e($title); ?></h1>
            <?php echo Form::open(['action' => 'AlbumsController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

            <div class="form-group">
                <?php echo e(Form::label('title', __('messages.title'))); ?>

                <?php echo e(Form::text('title', '', ['class' => "form-control", 'placeholder' => __('messages.title') . '...'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('description', __('messages.description') . ' (' . __('messages.optional') . ')*')); ?>

                <?php echo e(Form::textarea('description', '', ['class' => "form-control", 'rows' => '3', 'placeholder' => __('messages.description') . '...'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('cover_image', __('messages.choose_cover_image') . ':')); ?>

                <?php echo e(Form::file('cover_image', ['class' => 'form-control-file'])); ?>

            </div>
            <?php echo e(Form::submit(__('messages.submit'), ['class' => 'btn btn-primary btn-lg'])); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/gallery/create.blade.php ENDPATH**/ ?>