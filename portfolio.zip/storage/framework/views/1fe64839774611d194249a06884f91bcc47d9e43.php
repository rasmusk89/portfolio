<?php $__env->startSection('content'); ?>
    <div class="custom-background">
        <a class="btn btn-light border border-secondary" href="/" role="button"><?php echo e(__('messages.go_back')); ?></a>
    </div>
    <hr>
    <div class="jumbotron text-center">
        <h1><?php echo e($title); ?></h1>
        <p><?php echo e($description); ?></p>
    </div>
    <div class="list-group text-center m-1">
        <a href="/gallery" class="list-group-item list-group-item-action project-list">
            <div class="d-flex w-100 justify-content-center">
                <h4 class="mb-2"><?php echo e(__('projects.photo_gallery')); ?></h4>
            </div>
        </a>
        <a href="/productapi" class="list-group-item list-group-item-action project-list">
            <div class="d-flex w-100 justify-content-center">
                <h4 class="mb-2"><?php echo e(__('projects.product_api')); ?></h4>
            </div>
        </a>
        <a href="/contacts" class="list-group-item list-group-item-action project-list">
            <div class="d-flex w-100 justify-content-center">
                <h4 class="mb-2"><?php echo e(__('projects.contact_book')); ?></h4>
            </div>
        </a>
        <a href="/gifs" class="list-group-item list-group-item-action project-list">
            <div class="d-flex w-100 justify-content-center">
                <h4 class="mb-2"><?php echo e(__('projects.gifs')); ?></h4>
            </div>
        </a>
        <a href="/contacts_school" class="list-group-item list-group-item-action project-list">
            <div class="d-flex w-100 justify-content-center">
                <h4 class="mb-2"><?php echo e(__('projects.contacts_school_project')); ?></h4>
            </div>
        </a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/pages/projects.blade.php ENDPATH**/ ?>