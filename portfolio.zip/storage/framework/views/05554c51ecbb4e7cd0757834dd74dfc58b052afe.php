<?php $__env->startSection('content'); ?>
    <a class="btn btn-dark" href="/" role="button"><?php echo e(__('messages.go_back')); ?></a>
    <hr>
    <div class="jumbotron text-center">
        <h1><?php echo e($title); ?></h1>
        <br>
        <div class="row">
            <div class="col-6">
                <ul class="text-left">
                    <li>Phone: +372 55 83 273</li>
                    <li>E-mail: rasmuskilk@gmail.com</li>
                    <li>LinkedIn: <a target="_blank" href="//www.linkedin.com/in/rasmus-kilk">linkedin.com/in/rasmus-kilk</a></li>
                </ul>
            </div>
            <div class="col-6">
                <form action="/contact" method="POST">
                    <div class="form-group text-left">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" id="name" value="<?php echo e(old('name')); ?>" placeholder="Enter name..">
                    </div>
                    <div class="form-group text-left">
                        <label for="email">E-mail</label>
                        <input type="email" class="form-control" id="email" value="<?php echo e(old('email')); ?>" placeholder="Enter email..">
                    </div>
                    <div class="form-group text-left">
                        <label for="message">Message</label>
                        <textarea class="form-control" rows="3" id="message" placeholder="Enter message.."></textarea>
                    </div>

                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-primary float-left">Send message</button>
                </form>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/pages/create.blade.php ENDPATH**/ ?>
