<?php $__env->startSection('content'); ?>
    <div class="custom-background">
        <a class="btn btn-light border border-secondary" href="/gallery" role="button"><?php echo e(__('messages.go_back')); ?></a>
    </div>
    <hr>
    <div class="custom-background">
        <?php echo $__env->make('gallery.include.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <hr>
    <?php echo $__env->make('gallery.include.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="custom-background">
    <h1><?php echo e($title); ?></h1>
    <?php if(count($albums) > 0): ?>
        <?php
        $colcount = count($albums);
        $i = 1;
        ?>
        <div id="albums">
            <div class="row text-center">
                <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($i == $colcount): ?>
                        <div class="col-md-4">
                            <a href="/gallery/albums/<?php echo e($album->id); ?>">
                                <img class="img-thumbnail m-2 p-3"
                                     src="<?php echo e(URL::asset("storage/album_covers/{$album->cover_image}")); ?>"
                                     alt="<?php echo e($album->name); ?>">
                                <br>
                            </a>
                            <h4><?php echo e($album->name); ?></h4>
                            <?php else: ?>
                                <div class="col-md-4">
                                    <a href="/gallery/albums/<?php echo e($album->id); ?>">
                                        <img class="img-thumbnail m-2 p-3"
                                             src="<?php echo e(URL::asset("storage/album_covers/{$album->cover_image}")); ?>"
                                             alt="<?php echo e($album->name); ?>">
                                        <br>
                                    </a>
                                    <h4><?php echo e($album->name); ?></h4>
                                    <br>
                                    <br>
                                    <?php endif; ?>
                                    <?php if($i % 3 == 0): ?>
                                </div>
                        </div>
                        <div class="row text-center">
                            <?php else: ?>
                        </div>
                    <?php endif; ?>
                    <?php $i++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php else: ?>
        <div>
            <p><strong><?php echo e(__('messages.no_albums')); ?></strong>
        </div>
    <?php endif; ?>
    <?php if(Auth::check()): ?>
        <div>
            <a class="btn btn-primary m-2" href="/gallery/create"><?php echo e(__('messages.create_album')); ?></a>
        </div>
    <?php else: ?>
        <div>
            <p><em> <?php echo e(__('messages.login_to_create_album')); ?>!*</em></p>
        </div>
    <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/gallery/albums.blade.php ENDPATH**/ ?>