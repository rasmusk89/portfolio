<div class="btn btn-dark">
    <a href="/projects">Go back</a>
</div>
<?php /**PATH C:\xampp\htdocs\portfolio\resources\views/include/back.blade.php ENDPATH**/ ?>