<?php $__env->startSection('content'); ?>
    <a class="btn btn-dark" href="/gallery/albums" role="button">Go back</a>
    <hr>
    <h1><?php echo e($album->name); ?></h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio\resources\views//gallery/show.blade.php ENDPATH**/ ?>