<?php $__env->startSection('content'); ?>
    <div class="custom-background">
        <a class="btn btn-light border border-secondary" href="/gallery/albums" role="button"><?php echo e(__('messages.go_back')); ?></a>
    </div>
    <hr>
    <div class="custom-background">
        <?php echo $__env->make('gallery.include.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <hr>
    <div class="custom-background">
        <?php echo $__env->make('gallery.include.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <h1><?php echo e($album->name); ?></h1>
        <hr>

        <?php if(count($album->photos) > 0): ?>
            <?php
            $colcount = count($album->photos);
            $i = 1;
            ?>
            <div id="photos">
                <div class="row text-center">
                    <?php $__currentLoopData = $album->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($i == $colcount): ?>
                            <div class="col-md-4 image_in_album">
                                <a href="/gallery/photos/<?php echo e($photo->id); ?>">
                                    <img class="img-fluid m-2 border border-light"
                                         src="<?php echo e(URL::asset("storage/photos/{$photo->album_id}/{$photo->photo}")); ?>"
                                         alt="<?php echo e($photo->title); ?>">
                                </a>
                                <?php else: ?>
                                    <div class="col-md-4 image_in_album">
                                        <a href="/gallery/photos/<?php echo e($photo->id); ?>">
                                            <img class="img-fluid m-2 border border-light"
                                                 src="<?php echo e(URL::asset("storage/photos/{$photo->album_id}/{$photo->photo}")); ?>"
                                                 alt="<?php echo e($photo->title); ?>">
                                            <br>
                                        </a>
                                        <br>
                                        <?php endif; ?>
                                        <?php if($i % 3 == 0): ?>
                                    </div>
                            </div>
                            <div class="row text-center">
                                <?php else: ?>
                            </div>
                        <?php endif; ?>
                        <?php $i++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php else: ?>
            <div>
                <p><strong><?php echo e(__('messages.no_photos')); ?></strong></p>
            </div>
        <?php endif; ?>
        <?php if(Auth::check()): ?>
            <a class="btn btn-primary" href="/gallery/photos/create/<?php echo e($album->id); ?>"><?php echo e(__('messages.upload_photo')); ?></a>
        <?php else: ?>
            <p><em> <?php echo e(__('messages.login_to_upload_image')); ?>!*</em></p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio\resources\views//gallery/albums/show.blade.php ENDPATH**/ ?>