<?php $__env->startSection('content'); ?>
    <div class="jumbotron text-center">
        <h1><?php echo e($title); ?></h1>
        <p><?php echo e($description); ?></p>
        <div>
            <a href="/about" class="btn btn-light btn-lg m-2 border border-secondary"><?php echo e(__('messages.about')); ?></a>
            <a href="/contact" class="btn btn-light btn-lg m-2 border border-secondary"><?php echo e(__('messages.contact')); ?></a>
            <a href="/projects" class="btn btn-light btn-lg m-2 border border-secondary"><?php echo e(__('messages.projects')); ?></a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/pages/index.blade.php ENDPATH**/ ?>