<?php $__env->startSection('content'); ?>
    <div class="custom-background">
        <a class="btn btn-light" href="/gallery/albums" role="button"><?php echo e(__('messages.go_back')); ?></a>
    </div>
    <hr>
    <div class="custom-background">
        <?php echo $__env->make('gallery.include.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <hr>
    <div class="custom-background">
        <div class="container">
            <?php echo $__env->make('gallery.include.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="form-group ml-3">
            <h1><?php echo e(__('messages.upload_photo')); ?></h1>
            <?php echo Form::open(['action' => 'PhotosController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

            <div class="form-group">
                <?php echo e(Form::label('title', __('messages.title'))); ?>

                <?php echo e(Form::text('title', '', ['class' => "form-control", 'placeholder' => __('messages.title') . '...'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('description', __('messages.description') . ' (' . __('messages.optional') . ')*')); ?>

                <?php echo e(Form::textarea('description', '', ['class' => "form-control", 'rows' => '3', 'placeholder' => __('messages.description') . '...'])); ?>

            </div>
            <?php echo e(Form::hidden('album_id', $album_id)); ?>

            <div class="form-group">
                <?php echo e(Form::label('photo', __('messages.choose_photo').':')); ?>

                <?php echo e(Form::file('photo', ['class' => 'form-control-file'])); ?>

            </div>
            <?php echo e(Form::submit(__('messages.submit'), ['class' => 'btn btn-primary btn-lg'])); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/gallery/photos/create.blade.php ENDPATH**/ ?>