<?php $__env->startSection('content'); ?>
    <a class="btn btn-dark" href="/projects" role="button"><?php echo e(__('messages.go_back')); ?></a>
    <hr>
    <div class="jumbotron text-center">
        <h1>Wordpress page</h1>
        <p>description of work</p>
        <a href="//rasmusk.ee/wordpress" target="_blank" class="text-decoration-none"><div class="btn btn-dark"><?php echo e(__('messages.go_to')); ?></div></a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/wordpress/index.blade.php ENDPATH**/ ?>