<?php $__env->startSection('content'); ?>
    <a class="btn btn-dark" href="/projects" role="button"><?php echo e(__('messages.go_back')); ?></a>
    <hr>
    <div id="app">
        <contacts></contacts>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/contact_book/contact_book/index.blade.php ENDPATH**/ ?>
