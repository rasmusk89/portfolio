<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('gallery.include.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <?php echo $__env->make('gallery.include.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="form-group ml-3">
        <h1><?php echo e($title); ?></h1>
        <?php echo Form::open(['action' => 'AlbumsController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

             <div class="form-group">
                 <?php echo e(Form::label('title', 'Title')); ?>

                 <?php echo e(Form::text('title', '', ['class' => "form-control", 'placeholder' => "Album title"])); ?>

             </div>
            <div class="form-group">
                <?php echo e(Form::label('description', 'Album description (optional)*')); ?>

                <?php echo e(Form::textarea('description', '', ['class' => "form-control", 'rows' => '3', 'placeholder' => "Album description"])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('cover_image', 'Choose a cover image')); ?>

                <?php echo e(Form::file('cover_image', ['class' => 'form-control-file'])); ?>

            </div>
            <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary btn-lg'])); ?>

        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/gallery/create.blade.php ENDPATH**/ ?>
