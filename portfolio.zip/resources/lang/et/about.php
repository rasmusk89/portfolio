<?php

return [
    'name' => 'Nimi',
    'location' => 'Elukoht',
    'estonia' => 'Eesti',
    'education' => 'Haridus',
    'distant' => 'Kaugõpe',
    'university' => 'Tallinna Tehnikaülikool',
    'field' => 'IT Süsteemide Arendus',
    'secondary' => 'Keskharidus',
    'basic' => 'Põhiharidus',
    'certificates' => 'Koolitused',
    'front_end' => 'Tarkvaraarenduse front-end',
    'academical_hours' => 'akadeemilist tundi',
    'it_specialist' => 'IT spetsialisti koolitus',
    'hardware' => 'Riistvara, tarkvara, veeb, turvalisus, pilveteenused',
    'skills' => 'Osuksed'

];
