<?php

return [
    'name' => 'Name',
    'location' => 'Location',
    'estonia' => 'Estonia',
    'education' => 'Education',
    'distant' => 'Distant studies',
    'university' => 'Tallinn University of Technology',
    'field' => 'IT Systems Development',
    'secondary' => 'Secondary education',
    'basic' => 'Basic education',
    'certificates' => 'Certificates',
    'front_end' => 'Software development Front-End',
    'academical_hours' => 'academical hours',
    'it_specialist' => 'IT specialist training',
    'hardware' => 'Hardware, software, web, security, cloud services',
    'skills' => 'Skills'



];
